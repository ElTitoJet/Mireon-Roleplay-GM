showPlayerHudComponent ( "vehicle_name", false )

--+++++++++++ COR DO DAMAGE
damageR, damageG, damageB = 255,0,0

--+++++++++++ COR DO TRACO
tracoR, tracoG, tracoB = 255,0,0

